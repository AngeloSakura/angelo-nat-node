// Bounded test data source. No filesystem or arbitrary proxy endpoints.
package main

import (
 "bufio"
 "bytes"
 "crypto/rand"
 "encoding/hex"
 "fmt"
 "net"
 "os"
 "strconv"
 "strings"
 "sync/atomic"
 "time"
)

func main() {
 secret := make([]byte, 16)
 if _, err := rand.Read(secret); err != nil { panic(err) }
 token := hex.EncodeToString(secret)
 if saved, err := os.ReadFile("/root/nat-validation/source.secret"); err == nil && len(saved)==32 { token=string(saved) }
 if err := os.WriteFile("/root/nat-validation/source.secret", []byte(token), 0600); err != nil { panic(err) }
 listener, err := net.Listen("tcp4", ":50003")
 if err != nil { panic(err) }
 defer listener.Close()
 data := bytes.Repeat([]byte{'x'}, 16384)
 slots := make(chan struct{}, 200)
 var total atomic.Int64
 for {
  connection, err := listener.Accept()
  if err != nil { panic(err) }
  select { case slots <- struct{}{}: default: connection.Close(); continue }
  go func(conn net.Conn) {
   defer func(){ conn.Close(); <-slots }()
   conn.SetDeadline(time.Now().Add(120*time.Second))
   // Loopback transfers stay bounded; public direct baselines use kernel autotuning.
   if tcp, ok := conn.(*net.TCPConn); ok && tcp.RemoteAddr().(*net.TCPAddr).IP.IsLoopback() { tcp.SetWriteBuffer(16384) }
   input := bufio.NewReaderSize(conn, 4096)
   line, err := input.ReadString('\n')
   if err != nil || len(line)>2048 { return }
   pieces := strings.Fields(line)
   if len(pieces)!=3 || pieces[0]!="GET" { return }
   path := strings.Split(pieces[1], "/")
   if len(path)!=3 || path[1]!=token { return }
   size, err := strconv.Atoi(path[2])
   if err != nil || size<1 || size>8*1024*1024 { return }
   if total.Add(int64(size))>6*1024*1024*1024 { return }
   for used:=0; used<8192; {
    header, err := input.ReadString('\n'); used+=len(header)
    if err!=nil { return }; if header=="\r\n" { break }
   }
   fmt.Fprintf(conn,"HTTP/1.1 200 OK\r\nContent-Length: %d\r\nConnection: close\r\n\r\n",size)
   for left:=size; left>0; {
    n:=len(data); if left<n { n=left }
    wrote, err:=conn.Write(data[:n]); if err!=nil { return }; left-=wrote
   }
  }(connection)
 }
}
