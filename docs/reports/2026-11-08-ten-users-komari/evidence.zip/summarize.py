"""Summarize ten-user results and correlate whole-container/process samples."""
import csv
import json
import pathlib

ROOT=pathlib.Path(__file__).resolve().parent
out=[]
for i in (1,2):
    directory=ROOT/f'node{i}-evidence'
    samples=[r for r in csv.DictReader((directory/'memory.csv').open()) if r.get('probe_rss_kib')]
    before=(directory/'before.txt').read_text().splitlines()
    offset=float(before[1])-float(before[2].split()[0])
    logs=[]
    for filename in [f'node{i}.jsonl', 'api-retest1.jsonl' if i==1 else 'recovery2.jsonl']:
        for line in (ROOT/filename).read_text().splitlines():
            row=json.loads(line); row['sourceLog']=filename; logs.append(row)
    base_kills=int(samples[0]['oom_kill'])
    base_oom=int(samples[0]['oom'])
    measurements=[]
    for r in logs:
        if 'startedUnix' not in r: continue
        selected=[s for s in samples if r['startedUnix']-1<=float(s['uptime'])+offset<=r['endedUnix']+1]
        if selected:
            r['samples']=len(selected)
            r['sampledContainerPeakMiB']=round(max(int(s['total_bytes']) for s in selected)/1048576,2)
            r['sampledSwapPeakBytes']=max(int(s['swap_bytes']) for s in selected)
            r['sampledProbeRssPeakMiB']=round(max(int(s['probe_rss_kib']) for s in selected)/1024,2)
            r['sampledXrayRssPeakMiB']=round(max(int(s['xray_rss_kib']) for s in selected)/1024,2)
            r['sampledSocketPeakMiB']=round(max(int(s['socket_bytes']) for s in selected)/1048576,2)
            r['oomKillIncreaseFromStart']=max(int(s['oom_kill']) for s in selected)-base_kills
            measurements.append(r)
    value={'node':f'node{i}','log':logs,'measurements':measurements,
        'overall':{'samples':len(samples),'swapPeakBytes':max(int(s['swap_bytes']) for s in samples),
            'sampledContainerPeakMiB':round(max(int(s['total_bytes']) for s in samples)/1048576,2),
            'oomIncrease':max(int(s['oom']) for s in samples)-base_oom,
            'oomKillIncrease':max(int(s['oom_kill']) for s in samples)-base_kills,
            'probePids':sorted({int(s['probe_pid']) for s in samples}),
            'xuiPids':sorted({int(s['xui_pid']) for s in samples})}}
    out.append(value)
    for r in measurements:
        print(f"node{i}",r['event'],r.get('connections',40),r.get('round','-'),r['requests'],r['failures'],r['apiFailures'],r['sampledContainerPeakMiB'],r['sampledProbeRssPeakMiB'])
    print(json.dumps(value['overall']))
(ROOT/'results.json').write_text(json.dumps(out,indent=2)+'\n')
