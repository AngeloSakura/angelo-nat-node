"""Reduce frozen public-network measurements; never reads credentials."""
import csv
import json
import pathlib

ROOT=pathlib.Path(__file__).resolve().parent
logs=['default-1','default-2','uncapped-1','uncapped-2','buffer128-1','recovery-1','recovery2-2']
results=[]
for log in logs:
    for line in (ROOT/'client-evidence'/f'{log}.jsonl').read_text().splitlines():
        row=json.loads(line)
        row['sourceLog']=log
        results.append(row)

def samples(path):
    return [row for row in csv.DictReader(path.open()) if row.get('swap_bytes')]

def offset(path):
    lines=path.read_text().splitlines()
    return float(lines[1])-float(lines[2].split()[0])

for row in results:
    node=row['node']
    root=ROOT/(node+'-evidence')
    if node=='node1':
        if row['sourceLog']=='default-1':
            file='memory-default.csv'; snap='after-default.txt'
        else:
            file='memory-extra.csv'; snap='after-buffer128.txt'
    elif row['sourceLog']=='recovery2-2':
        file='memory-recovery.csv'; snap='after-recovery.txt'
    else:
        file='memory-before-reboot.csv'; snap='after-default.txt'
    off=offset(root/snap)
    # The snapshots have integer wall-clock seconds; allow a 1 s alignment margin.
    rows=[r for r in samples(root/file) if row['startedUnix']-1<=float(r['uptime'])+off<=row['endedUnix']+1]
    row['memorySamples']=len(rows)
    row['sampledContainerPeakMiB']=round(max(int(r['total_bytes']) for r in rows)/1048576,2) if rows else None
    row['sampledSwapPeakBytes']=max(int(r['swap_bytes']) for r in rows) if rows else None

output={'scope':'Real NAT VPS containers including OS, SSH, source, sampler, and existing services. Samples every 0.2 s; no swap. Short bursts, no long-term guarantee.','results':results}
(ROOT/'results.json').write_text(json.dumps(output,indent=2)+'\n')
for row in results:
    print(row['node'],row['phase'],row['transport'],row['connections'],row['Mbps'],row['failures'],row['sampledContainerPeakMiB'])
