"""Bounded public-network benchmark. Only dedicated test-node APIs are modified."""
import concurrent.futures
import http.client
import json
import pathlib
import socket
import ssl
import statistics
import struct
import sys
import time
import urllib.request
import uuid

ROOT = pathlib.Path(__file__).resolve().parent
NODES = json.loads((ROOT/'benchmark-private.json').read_text())

def api(node, path, body=None):
    context = ssl.create_default_context(cadata=node['certificate'])
    context.check_hostname = False  # Trust only this test node's downloaded certificate.
    request = urllib.request.Request(
        'https://'+node['host']+':50001/panel/api/'+path,
        data=None if body is None else json.dumps(body).encode(),
        headers={'Authorization':'Bearer '+node['token'], 'Content-Type':'application/json'})
    with urllib.request.urlopen(request, context=context, timeout=20) as response:
        value = json.load(response)
    if not value['success']:
        raise RuntimeError('test node API operation failed: '+path)
    return value['obj']

def configure(node, tls):
    existing = api(node, 'inbounds/list')
    others = [item for item in existing if item.get('tag') != 'nat-vps-validation']
    assert not others, 'Refusing to change a node with non-test inbounds'
    inbound = {'enable':True, 'port':50002, 'listen':'0.0.0.0', 'protocol':'vless',
        'tag':'nat-vps-validation', 'settings':{'decryption':'none','clients':[
            {'id':node['uuid'],'email':'nat-vps-validation','enable':True,'totalGB':8*1024**3}]},
        'streamSettings':{'network':'tcp','security':'none'}}
    if tls:
        inbound['streamSettings'].update({'security':'tls','tlsSettings':{
            'certificates':[{'certificateFile':node['tlsCert'],'keyFile':node['tlsKey']}]}})
    path = 'inbounds/add'
    if existing:
        inbound['id'] = existing[0]['id']
        path = 'inbounds/update/'+str(inbound['id'])
    api(node, path, inbound)

def fetch(node, mode, size):
    started = time.monotonic()
    first_byte = None
    received = 0
    try:
        port = 50003 if mode == 'direct' else 50002
        with socket.create_connection((node['host'],port),timeout=15) as raw:
            raw.settimeout(60)
            conn = raw
            if mode == 'tls':
                context = ssl.create_default_context(cadata=node['certificate'])
                context.check_hostname = False
                conn = context.wrap_socket(raw,server_hostname='localhost')
            try:
                request = ('GET /'+node['sourceSecret']+'/'+str(size)+
                    ' HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n').encode()
                if mode != 'direct':
                    request = (b'\x00'+uuid.UUID(node['uuid']).bytes+b'\x00\x01'+
                        struct.pack('!H',50003)+b'\x01\x7f\x00\x00\x01'+request)
                conn.sendall(request)
                if mode != 'direct':
                    response_header = b''
                    while len(response_header)<2:
                        chunk = conn.recv(2-len(response_header))
                        if not chunk: raise RuntimeError('missing VLESS response')
                        response_header += chunk
                    if response_header != b'\x00\x00': raise RuntimeError('invalid VLESS response')
                response = http.client.HTTPResponse(conn)
                response.begin()
                first_byte = time.monotonic()-started
                if response.status != 200: raise RuntimeError('HTTP status '+str(response.status))
                while True:
                    chunk = response.read(65536)
                    if not chunk: break
                    received += len(chunk)
                    if chunk != b'x'*len(chunk): raise RuntimeError('payload corruption')
                if received != size: raise RuntimeError('short body')
            finally:
                if conn is not raw: conn.close()
        return {'ok':True,'bytes':received,'ttfb':first_byte,'seconds':time.monotonic()-started}
    except Exception as error:
        # Exceptions may include URLs; emit type only, with no bearer/source secrets.
        return {'ok':False,'bytes':received,'error':type(error).__name__,
                'ttfb':first_byte,'seconds':time.monotonic()-started}

def bench(node, mode, label, concurrencies=(1,8,32), size=4*1024**2):
    passed = True
    for concurrency in concurrencies:
        started_unix = time.time()
        start = time.monotonic()
        with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:
            results = list(pool.map(lambda _:fetch(node,mode,size),range(concurrency)))
        elapsed = time.monotonic()-start
        total = sum(result['bytes'] for result in results)
        tt = [result['ttfb'] for result in results if result['ttfb'] is not None]
        value = {'node':node['name'],'phase':label,'transport':mode,'connections':concurrency,
            'startedUnix':round(started_unix,3),'endedUnix':round(time.time(),3),
            'bytes':total,'seconds':round(elapsed,3),'Mbps':round(total*8/elapsed/1e6,2),
            'failures':sum(not result['ok'] for result in results),
            'ttfbMedianMs':round(statistics.median(tt)*1000,1) if tt else None,
            'errors':[result.get('error') for result in results if not result['ok']]}
        print(json.dumps(value),flush=True)
        if value['failures']:
            passed = False
            break
        time.sleep(2)
    return passed

def main():
    action, node_index = sys.argv[1], int(sys.argv[2])-1
    node = NODES[node_index]
    if action == 'prepare':
        configure(node,False)
        print(json.dumps({'node':node['name'],'prepared':True}),flush=True)
    elif action == 'baseline':
        bench(node,'direct','direct-source-16KiB')
        configure(node,False)
        bench(node,'plain','default-32KiB')
        configure(node,True)
        bench(node,'tls','default-32KiB')
    elif action == 'direct':
        bench(node,'direct','direct-kernel-autotuning')
    elif action == 'proxy':
        configure(node,False)
        bench(node,'plain','default-32KiB')
        configure(node,True)
        bench(node,'tls','default-32KiB')
    elif action == 'uncapped':
        configure(node,False)
        bench(node,'plain','kernel-autotuning')
        configure(node,True)
        bench(node,'tls','kernel-autotuning')
    elif action == 'recovery':
        configure(node,True)
        if not bench(node,'tls','default-32KiB-recovery',(32,32,32,32),8*1024**2):
            sys.exit(1)
    elif action == 'buffer128':
        configure(node,False)
        if not bench(node,'plain','bounded-128KiB'): sys.exit(1)
        configure(node,True)
        if not bench(node,'tls','bounded-128KiB'): sys.exit(1)
    elif action == 'cleanup':
        existing = api(node,'inbounds/list')
        for item in existing:
            if item.get('tag') == 'nat-vps-validation':
                api(node,'inbounds/del/'+str(item['id']),{})
        print(json.dumps({'node':node['name'],'testInboundRemoved':True}),flush=True)
    else:
        raise ValueError('unknown action')

if __name__ == '__main__':
    main()
