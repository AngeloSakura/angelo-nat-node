#!/bin/sh
set -eu
printf 'uptime,total_bytes,swap_bytes\n'
for unused in $(seq 1 3600); do
 [ ! -e /root/nat-validation/stop-sampling ] || break
 read -r uptime rest < /proc/uptime
 read -r total < /sys/fs/cgroup/memory.current
 read -r swap < /sys/fs/cgroup/memory.swap.current
 printf '%s,%s,%s\n' "$uptime" "$total" "$swap"
 sleep .2
done
