#!/bin/sh
set -eu
umask 077
cd /root/nat-validation/master-accounting
touch stop-sampling
if [ -f source.pid ]; then
 p=$(cat source.pid)
 if [ -r /proc/"$p"/comm ] && [ "$(cat /proc/"$p"/comm)" = http-source ]; then kill "$p"; fi
fi
sh /root/nat-validation/snapshot.sh > after.txt
if [ -e /etc/alpine-release ]; then config=/etc/nat-validation/config.json; else config=/etc/angelo-node/config.json; fi
cp original-config.json "$config"
if [ -e /etc/alpine-release ]; then rc-service x-ui-nat-test restart; else systemctl restart angelo-node; fi
cmp original-config.json "$config"
echo 'Original config restored; source and sampling stopped'
