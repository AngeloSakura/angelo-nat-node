#!/bin/sh
set -eu
umask 077
root=/root/nat-validation/master-accounting
cd "$root"
[ "$(cat /sys/fs/cgroup/memory.swap.max)" = 0 ]
[ "$(cat /sys/fs/cgroup/memory.swap.current)" = 0 ]
if [ -e /etc/alpine-release ]; then config=/etc/nat-validation/config.json; else config=/etc/angelo-node/config.json; fi
[ ! -e original-config.json ]
cp "$config" original-config.json
cp test-config.json "$config"
if [ -e /etc/alpine-release ]; then rc-service x-ui-nat-test restart; else systemctl restart angelo-node; fi
sh /root/nat-validation/snapshot.sh > before.txt
cp /root/nat-validation/ten-users/http-source ./http-source
chmod 700 ./http-source
nohup env GOMEMLIMIT=8MiB GOGC=50 GOMAXPROCS=1 ./http-source > source.log 2>&1 < /dev/null &
echo "$!" > source.pid
nohup sh sample.sh > memory.csv 2>sample.log < /dev/null &
echo "$!" > sampler.pid
echo 'Swap disabled; source and sampler started; Komari retained'
