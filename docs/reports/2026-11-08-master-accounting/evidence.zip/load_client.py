"""Ten independent VLESS identities with bounded burst and sustained traffic."""
import asyncio
import collections
import json
import pathlib
import ssl
import statistics
import struct
import sys
import time
import urllib.request
import uuid

ROOT=pathlib.Path(__file__).resolve().parent
NODES=json.loads((ROOT/'benchmark-private.json').read_text())
node=NODES[int(sys.argv[2])-1]
TLS=ssl.create_default_context(cadata=node['certificate'])
TLS.check_hostname=False
TAG='nat-ten-user-validation'
IDENTITIES=[str(uuid.uuid5(uuid.UUID(node['uuid']),f'ten-user-{i}')) for i in range(10)]
EMAILS=[f'nat-ten-user-{i+1:02d}' for i in range(10)]

def classify(message):
    for text,code in [('configuration update','config_busy'),('too many concurrent','api_busy'),
            ('stats not responding','xray_stats_timeout'),('Xray is not running','xray_stopped'),
            ('node reconciliation','reconciliation_error')]:
        if text in message: return code
    return 'unspecified_node_error'

def api(path,body=None):
    request=urllib.request.Request('https://'+node['host']+':50001/panel/api/'+path,
        data=None if body is None else json.dumps(body).encode(),
        headers={'Authorization':'Bearer '+node['token'],'Content-Type':'application/json'})
    with urllib.request.urlopen(request,context=TLS,timeout=12) as response:
        result=json.load(response)
    if not result['success']:
        error=RuntimeError('node_api_failed')
        error.category=classify(result.get('msg',''))
        raise error
    return result['obj']

def emit(value):
    print(json.dumps({'node':node['name'],**value}),flush=True)

def configure():
    existing=api('inbounds/list')
    assert all(item.get('tag')==TAG for item in existing), 'non-test inbound present'
    inbound={'enable':True,'port':50002,'listen':'0.0.0.0','protocol':'vless','tag':TAG,
        'settings':{'decryption':'none','clients':[{'id':ident,'email':email,'enable':True,'totalGB':4*1024**3} for ident,email in zip(IDENTITIES,EMAILS)]},
        'streamSettings':{'network':'tcp','security':'tls','tlsSettings':{'certificates':[{
            'certificateFile':node['tlsCert'],'keyFile':node['tlsKey']}]}}}
    path='inbounds/add'
    if existing:
        inbound['id']=existing[0]['id']; path='inbounds/update/'+str(inbound['id'])
    api(path,inbound)
    emit({'event':'configured','users':10,'transport':'VLESS TCP TLS'})

async def fetch(user,size):
    started=time.monotonic(); writer=None; received=0; first_byte=None
    try:
        async with asyncio.timeout(45):
            reader,writer=await asyncio.open_connection(node['host'],50002,ssl=TLS,
                server_hostname='localhost',ssl_handshake_timeout=12,limit=32768)
            request=('GET /'+node['sourceSecret']+'/'+str(size)+' HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n').encode()
            writer.write(b'\x00'+uuid.UUID(IDENTITIES[user]).bytes+b'\x00\x01'+struct.pack('!H',50003)+b'\x01\x7f\x00\x00\x01'+request)
            await writer.drain()
            if await reader.readexactly(2)!=b'\x00\x00': raise RuntimeError('invalid_vless_header')
            headers=await reader.readuntil(b'\r\n\r\n')
            first_byte=time.monotonic()-started
            if not headers.startswith(b'HTTP/1.1 200 '): raise RuntimeError('http_status')
            while received<size:
                chunk=await reader.read(min(32768,size-received))
                if not chunk: raise RuntimeError('short_body')
                if chunk!=b'x'*len(chunk): raise RuntimeError('corrupt_body')
                received+=len(chunk)
        return {'ok':True,'user':user,'bytes':received,'seconds':time.monotonic()-started,'ttfb':first_byte}
    except Exception as error:
        kind=str(error) if type(error) is RuntimeError else type(error).__name__
        return {'ok':False,'user':user,'bytes':received,'seconds':time.monotonic()-started,'ttfb':first_byte,'error':kind}
    finally:
        if writer:
            writer.close()
            try: await asyncio.wait_for(writer.wait_closed(),2)
            except Exception: pass

def aggregate(values):
    ttfb=sorted(r['ttfb']*1000 for r in values if r['ttfb'] is not None)
    return {'requests':len(values),'failures':sum(not r['ok'] for r in values),
        'bytes':sum(r['bytes'] for r in values),
        'successfulUsers':len({r['user'] for r in values if r['ok']}),
        'ttfbMedianMs':round(statistics.median(ttfb),1) if ttfb else None,
        'ttfbP95Ms':round(ttfb[min(len(ttfb)-1,int(len(ttfb)*.95))],1) if ttfb else None,
        'errors':dict(collections.Counter(r['error'] for r in values if not r['ok']))}

async def monitor(stop,rows):
    while not stop.is_set():
        start=time.monotonic()
        try:
            await asyncio.to_thread(api,'server/health')
            rows.append({'ok':True,'ms':1000*(time.monotonic()-start)})
        except Exception as error:
            category=getattr(error,'category',None)
            if getattr(error,'code',None):
                try:
                    body=error.read().decode('utf-8')
                    try: body=json.loads(body).get('msg','')
                    except ValueError: pass
                    category=classify(body)
                except Exception: pass
            failure={'ok':False,'error':type(error).__name__,'httpStatus':getattr(error,'code',None),'category':category}
            rows.append(failure)
            emit({'event':'api-failure','unix':time.time(),**failure})
        try: await asyncio.wait_for(stop.wait(),3)
        except TimeoutError: pass

async def burst(per_user,round_number):
    started=time.time(); tick=time.monotonic(); health=[]; stop=asyncio.Event()
    monitoring=asyncio.create_task(monitor(stop,health))
    values=await asyncio.gather(*(fetch(user,2*1024**2) for user in range(10) for _ in range(per_user)))
    stop.set(); await monitoring
    elapsed=time.monotonic()-tick
    result={'event':'burst','users':10,'connectionsPerUser':per_user,'connections':10*per_user,
        'round':round_number,'startedUnix':started,'endedUnix':time.time(),
        'seconds':round(elapsed,3),**aggregate(values),
        'apiChecks':len(health),'apiFailures':sum(not r['ok'] for r in health)}
    result['Mbps']=round(result['bytes']*8/elapsed/1e6,2)
    emit(result)
    return result['failures']==0 and result['successfulUsers']==10

async def soak():
    started=time.time(); tick=time.monotonic(); deadline=tick+120
    values=[]; health=[]; stop=asyncio.Event(); budget=1536*1024**2; claimed=0
    monitoring=asyncio.create_task(monitor(stop,health))
    async def worker(user):
        nonlocal claimed
        while time.monotonic()<deadline and claimed+1024**2<=budget and not stop.is_set():
            claimed+=1024**2
            result=await fetch(user,1024**2); values.append(result)
            if not result['ok']: stop.set(); return
            await asyncio.sleep(max(0,3-result['seconds']))
    await asyncio.gather(*(worker(user) for user in range(10) for _ in range(4)))
    stop.set(); await monitoring
    elapsed=time.monotonic()-tick
    result={'event':'soak','users':10,'connectionsPerUser':4,'startedUnix':started,'endedUnix':time.time(),
        'seconds':round(elapsed,3),**aggregate(values),'apiChecks':len(health),'apiFailures':sum(not r['ok'] for r in health)}
    result['Mbps']=round(result['bytes']*8/elapsed/1e6,2); emit(result)
    return result['failures']==0 and result['successfulUsers']==10

async def run():
    configure()
    for per_user in (4,8,16):
        for number in (1,2):
            if not await burst(per_user,number): return False
            await asyncio.sleep(4)
    if not await soak(): return False
    await asyncio.sleep(11)
    rows=api('inbounds/list')[0].get('clientStats',[])
    active={r.get('email') for r in rows if r.get('down',0)>0}
    emit({'event':'accounting','usersWithTraffic':len(active.intersection(EMAILS))})
    return len(active.intersection(EMAILS))==10

