"""Real master->NAT->master accounting test, isolated PG and synthetic users."""
import asyncio,hashlib,json,pathlib,secrets,ssl,subprocess,sys,time,urllib.request,uuid
import load_client as c
R=pathlib.Path(__file__).resolve().parent
s=json.loads((R/'state.json').read_text())
index=int(sys.argv[2]); node=c.node
c.TAG='nat-master-accounting'
c.EMAILS=[f'master-node{index}-user{i+1:02d}' for i in range(10)]
c.IDENTITIES=[str(uuid.uuid5(uuid.UUID(node['uuid']),email)) for email in c.EMAILS]
pgargs=['psql','--no-psqlrc','-h',str(R/'sock'),'-p','55432','-U','postgres','-d','nat_fixture','-qAt','-v','ON_ERROR_STOP=1']
def sql(query,readonly=True):
    prefix='BEGIN READ ONLY; SET LOCAL statement_timeout=5000;' if readonly else 'BEGIN;'
    p=subprocess.run(pgargs,input=prefix+query+';COMMIT;',capture_output=True,text=True,timeout=10)
    if p.returncode: raise RuntimeError('fixture_sql_failed')
    return json.loads(p.stdout.strip()) if p.stdout.strip() else None
def emit(v):c.emit(v)
def api(route,body=None):
    req=urllib.request.Request('http://127.0.0.1:'+str(s['port'])+s['base']+'panel/api/'+route,
        data=None if body is None else json.dumps(body).encode(),
        headers={'Authorization':'Bearer '+s['token'],'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'})
    with urllib.request.urlopen(req,timeout=15) as resp: result=json.load(resp)
    if not result.get('success'): raise RuntimeError('fixture_api_failed:'+route)
    return result.get('obj')
def wait(label,predicate,seconds=150):
    start=time.monotonic(); last=None
    while time.monotonic()-start<seconds:
        try:
            value=predicate()
            if value: return value
        except Exception as e: last=type(e).__name__
        time.sleep(2)
    raise RuntimeError('timeout:'+label+':'+str(last))
def counters():
    return sql("""SELECT coalesce(json_agg(row_to_json(t)),'[]'::json) FROM (
      SELECT n.email,n.up AS raw_up,n.down AS raw_down,c.up AS billed_up,c.down AS billed_down,
       coalesce(a.expected_up,0) AS expected_up,coalesce(a.expected_down,0) AS expected_down,
       coalesce(a.changes,0) AS changes, coalesce(a.decreases,0) AS decreases
      FROM node_client_traffics n JOIN client_traffics c ON c.email=n.email
      LEFT JOIN (SELECT email,sum(round(greatest(new_up-old_up,0)*2.5))::bigint expected_up,
       sum(round(greatest(new_down-old_down,0)*2.5))::bigint expected_down,
       count(*) FILTER(WHERE new_up<>old_up OR new_down<>old_down) changes,
       count(*) FILTER(WHERE new_up<old_up OR new_down<old_down) decreases
       FROM accounting_audit GROUP BY email) a ON a.email=n.email
      WHERE n.node_id="""+str(s['nodes'][str(index)]['id'])+' ORDER BY n.email) t')
def nodecounters():
    return {x['email']:x for ib in c.api('inbounds/list') for x in ib.get('clientStats',[]) if x['email'] in c.EMAILS}
def settled():
    raw=nodecounters(); rows=counters()
    if len(rows)!=10 or len(raw)!=10:return None
    if any(r['raw_up']!=raw[r['email']]['up'] or r['raw_down']!=raw[r['email']]['down'] for r in rows):return None
    return rows
def verify(label,require_traffic=True):
    start=time.monotonic();rows=wait('raw_sync_'+label,settled)
    for r in rows:
        assert r['billed_up']==r['expected_up'] and r['billed_down']==r['expected_down'],'exact_billing_mismatch'
        assert r['decreases']==0,'raw_counter_decreased'
        if require_traffic: assert r['raw_down']>0 and r['raw_up']>0,'missing_user_traffic'
        a=api('clients/traffic/'+r['email'])
        assert a['up']==r['billed_up'] and a['down']==r['billed_down'],'master_api_disagrees_with_db'
    emit({'event':'verified','label':label,'settleSeconds':round(time.monotonic()-start,2),
        'users':10,'multiplier':2.5,'exactPerPollRoundingMatch':True,'rows':rows})
    return rows
def setup():
    assert not c.api('inbounds/list'), 'test_node_not_empty'
    if not s.get('auditReady'):
        sql('''CREATE TABLE accounting_audit (id bigserial PRIMARY KEY,ts timestamptz DEFAULT clock_timestamp(),
         node_id bigint,email text,old_up bigint,old_down bigint,new_up bigint,new_down bigint);
        CREATE FUNCTION audit_raw() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
          INSERT INTO accounting_audit(node_id,email,old_up,old_down,new_up,new_down)
          VALUES(NEW.node_id,NEW.email,CASE WHEN TG_OP='INSERT' THEN 0 ELSE OLD.up END,
           CASE WHEN TG_OP='INSERT' THEN 0 ELSE OLD.down END,NEW.up,NEW.down); RETURN NEW; END $$;
        CREATE TRIGGER capture_raw AFTER INSERT OR UPDATE ON node_client_traffics FOR EACH ROW EXECUTE FUNCTION audit_raw()''',False)
        s['auditReady']=True
    cert=ssl.PEM_cert_to_DER_cert(node['certificate'])
    n=api('nodes/add',{'name':'isolated-nat-'+str(index),'scheme':'https','address':node['host'],'port':50001,'basePath':'/',
        'apiToken':node['token'],'enable':True,'allowPrivateAddress':False,'tlsVerifyMode':'pin',
        'pinnedCertSha256':hashlib.sha256(cert).hexdigest(),'inboundSyncMode':'all','inboundTags':[],'trafficMultiplier':2.5})
    s.setdefault('nodes',{})[str(index)]={'id':n['id']}
    (R/'state.json').write_text(json.dumps(s))
    wait('heartbeat',lambda:api('nodes/get/'+str(n['id'])).get('status')=='online')
    ib=api('inbounds/add',{'nodeId':n['id'],'enable':True,'remark':'isolated-accounting','listen':'0.0.0.0','port':50002,
        'protocol':'vless','tag':c.TAG,'up':0,'down':0,'total':0,'expiryTime':0,'trafficReset':'never','trafficResetDay':1,
        'settings':{'clients':[],'decryption':'none'},'streamSettings':{'network':'tcp','security':'tls',
        'tlsSettings':{'certificates':[{'certificateFile':node['tlsCert'],'keyFile':node['tlsKey']}]}},
        'sniffing':{'enabled':False},'shareAddrStrategy':'node'})
    s['nodes'][str(index)]['inbound']=ib['id'];(R/'state.json').write_text(json.dumps(s))
    for ident,email in zip(c.IDENTITIES,c.EMAILS):
        api('clients/add',{'client':{'id':ident,'email':email,'enable':True,'flow':'','security':'auto','limitIp':0,
            'totalGB':10*1024**3,'expiryTime':0,'subId':secrets.token_hex(8),'reset':0,'trafficReset':'never','trafficResetDay':1},'inboundIds':[ib['id']]})
    rows=verify('baseline',False)
    assert all(r['raw_up']==r['raw_down']==r['billed_up']==r['billed_down']==0 for r in rows),'nonzero_baseline'
    emit({'event':'setup-complete','users':10,'createdThroughMaster':True,'database':'PostgreSQL','tlsPinVerified':True})
async def watch(stop):
    while not stop.is_set():
        try:
            rows=await asyncio.to_thread(counters)
            emit({'event':'master-sample','unix':time.time(),'rawDown':sum(r['raw_down'] for r in rows),
                'billedDown':sum(r['billed_down'] for r in rows),'exactMatch':all(r['billed_up']==r['expected_up'] and r['billed_down']==r['expected_down'] for r in rows)})
        except Exception as e: emit({'event':'master-sample-error','error':type(e).__name__})
        try:await asyncio.wait_for(stop.wait(),2)
        except TimeoutError:pass
async def load():
    stop=asyncio.Event(); task=asyncio.create_task(watch(stop)); passed=True
    try:
        for concurrency in ((4,8,16) if index==1 else (4,8)):
            for number in (1,2):
                ok=await c.burst(concurrency,number)
                await asyncio.to_thread(verify,f'burst-{concurrency*10}-{number}')
                if not ok: passed=False;break
            if not passed:break
        # A full push interval idle detects feedback/double counting.
        before=await asyncio.to_thread(verify,'pre-idle')
        await asyncio.sleep(36)
        after=await asyncio.to_thread(verify,'post-idle')
        fields=('email','raw_up','raw_down','billed_up','billed_down')
        assert [[r[k] for k in fields] for r in before]==[[r[k] for k in fields] for r in after],'idle_double_billing'
        emit({'event':'complete','dataPlanePassed':passed,'accountingPassed':True,'idleNoDoubleBilling':True})
    finally:stop.set();await task
def cleanup():
    ib=s.get('nodes',{}).get(str(index),{}).get('inbound')
    if ib: api('inbounds/del/'+str(ib),{})
    wait('node_inbound_removed',lambda:not c.api('inbounds/list'))
    emit({'event':'cleanup','testInboundRemoved':True})
try:
    if sys.argv[1]=='setup':setup()
    elif sys.argv[1]=='run':asyncio.run(load())
    elif sys.argv[1]=='verify':verify('manual')
    elif sys.argv[1]=='cleanup':cleanup()
    else:raise ValueError('unknown_operation')
except Exception as e:
    emit({'event':'fatal','error':type(e).__name__,'category':str(e) if type(e) in (AssertionError,RuntimeError,ValueError) else 'transport_or_runtime_error'})
    sys.exit(1)
