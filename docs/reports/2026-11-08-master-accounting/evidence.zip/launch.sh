#!/bin/sh
set -eu
root=/var/lib/nat-accounting-20261108
case "$1" in setup|run|verify|cleanup|recoveryverify) ;; *) exit 2;; esac
case "$2" in 1|2) ;; *) exit 2;; esac
exec systemd-run --unit="nat-accounting-client-$1-$2" --wait --collect \
 --property=MemoryMax=256M --property=CPUQuota=60% --property=Nice=15 \
 --property=RuntimeMaxSec=1800 --property=ProtectSystem=strict --property=ProtectHome=yes \
 --property=NoNewPrivileges=yes --property="ReadWritePaths=$root" \
 --property='InaccessiblePaths=/etc/x-ui /usr/local/x-ui /var/lib/postgresql' \
 --property="StandardOutput=append:$root/node$2-$1.jsonl" \
 --property="StandardError=append:$root/node$2-$1.stderr" \
 /usr/bin/python3 "$root/run.py" "$1" "$2"
