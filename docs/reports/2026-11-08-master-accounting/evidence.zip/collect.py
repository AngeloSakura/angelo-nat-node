"""Export only synthetic accounting rows and nonsecret runtime evidence."""
import hashlib,json,pathlib,subprocess,tarfile
R=pathlib.Path('/var/lib/nat-accounting-20261108')
args=['psql','--no-psqlrc','-h',str(R/'sock'),'-p','55432','-U','postgres','-d','nat_fixture','-qAt','-v','ON_ERROR_STOP=1']
query="BEGIN READ ONLY;SELECT coalesce(json_agg(row_to_json(t)),'[]'::json) FROM (SELECT id,ts,node_id,email,old_up,old_down,new_up,new_down FROM accounting_audit ORDER BY id) t;COMMIT;"
result=subprocess.run(args,input=query,text=True,capture_output=True,check=True,timeout=15)
rows=json.loads(result.stdout);(R/'audit-evidence.json').write_text(json.dumps(rows,indent=2))
runtime={}
for unit in ['x-ui','nat-accounting-master','nat-accounting-pg']:
    value=subprocess.check_output(['systemctl','show',unit,'-p','MainPID','-p','NRestarts','-p','MemoryCurrent','-p','CPUUsageNSec'],text=True)
    runtime[unit]=dict(row.split('=',1) for row in value.splitlines() if '=' in row)
runtime['productionSha']=hashlib.sha256(pathlib.Path('/usr/local/x-ui/x-ui').read_bytes()).hexdigest()
runtime['fixtureSha']=hashlib.sha256((R/'install/x-ui').read_bytes()).hexdigest()
(R/'runtime-evidence.json').write_text(json.dumps(runtime,indent=2))
names=[p.name for pattern in ['node*-*.jsonl','node*-*.stderr','launch-*.log','production-*.json','*-evidence.json'] for p in R.glob(pattern)]
with tarfile.open(R/'evidence.tar.gz','w:gz') as t:
    for name in sorted(set(names)):t.add(R/name,arcname=name)
print(json.dumps({'auditRows':len(rows),'evidenceFiles':len(set(names)),'productionPid':runtime['x-ui']['MainPID']}))
