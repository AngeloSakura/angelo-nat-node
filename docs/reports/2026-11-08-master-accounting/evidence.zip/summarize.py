import collections,csv,hashlib,json,pathlib
R=pathlib.Path(__file__).resolve().parent
E=R/'evidence'
audit=json.loads((E/'audit-evidence.json').read_text())
independent=collections.defaultdict(lambda:[0,0])
for row in audit:
    for k,field in enumerate(('up','down')):
        delta=row['new_'+field]-row['old_'+field]
        assert delta>=0,'raw counter reset during test'
        independent[row['email']][k]+=(delta*5+1)//2
result={}
for index in (1,2):
    events=[json.loads(line) for line in (E/f'node{index}-run.jsonl').read_text().splitlines()]
    bursts=[r for r in events if r['event']=='burst']
    checks=[r for r in events if r['event']=='master-sample']
    final=events
    if index==2: final=[json.loads(line) for line in (E/'node2-recoveryverify.jsonl').read_text().splitlines()]
    rows=[r for r in final if r['event']=='verified'][-1]['rows']
    samples=list(csv.DictReader((E/f'node{index}-memory.csv').open()))
    globalrows=json.loads((R/f'node{index}-global-evidence.json').read_text())
    for row in rows:
        assert row['billed_up']==row['expected_up'] and row['billed_down']==row['expected_down']
        assert independent[row['email']]==[row['billed_up'],row['billed_down']]
        glob=next(r for r in globalrows if r['user']==row['email'])
        assert glob['pushedUp']==row['billed_up'] and glob['pushedDown']==row['billed_down']
        assert glob['rawUp']==row['raw_up'] and glob['rawDown']==row['raw_down']
    received=sum(r['bytes'] for r in bursts)
    assert sum(r['raw_down'] for r in rows)>=received
    assert len(rows)==10
    result[f'node{index}']={'bursts':bursts,'requests':sum(r['requests'] for r in bursts),
     'failures':sum(r['failures'] for r in bursts),'receivedBytes':received,
     'rawUp':sum(r['raw_up'] for r in rows),'rawDown':sum(r['raw_down'] for r in rows),
     'billedUp':sum(r['billed_up'] for r in rows),'billedDown':sum(r['billed_down'] for r in rows),
     'exactBillingUsers':len(rows),'globalPushMatches':True,'masterSamples':len(checks),
     'badBillingSamples':sum(not x['exactMatch'] for x in checks),
     'apiChecks':sum(r['apiChecks'] for r in bursts),'apiFailures':sum(r['apiFailures'] for r in bursts),
     'wholeWindowPeakMiB':max(int(s['total_bytes']) for s in samples)/1024**2,
     'maxSwapBytes':max(int(s['swap_bytes']) for s in samples),
     'newOomKills':int(samples[-1]['oom_kill'])-int(samples[0]['oom_kill']),
     'samples':len(samples),'finalEvent':final[-1]}
(R/'results.json').write_text(json.dumps(result,indent=2))
for key,value in result.items():print(json.dumps({key:{k:v for k,v in value.items() if k not in ('bursts','finalEvent')}}))
