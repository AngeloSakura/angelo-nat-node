#!/bin/sh
set -eu
printf 'uptime,total_bytes,swap_bytes,anon_bytes,socket_bytes,oom,oom_kill,xui_pid,xui_rss_kib,xray_pid,xray_rss_kib,probe_pid,probe_rss_kib\n'
for unused in $(seq 1 2400); do
 [ ! -e /root/nat-validation/master-accounting/stop-sampling ] || break
 read -r uptime rest < /proc/uptime
 read -r total < /sys/fs/cgroup/memory.current
 read -r swap < /sys/fs/cgroup/memory.swap.current
 anon=0; sock=0; oom=0; kills=0
 while read -r key value; do case "$key" in anon) anon=$value;; sock) sock=$value;; esac; done < /sys/fs/cgroup/memory.stat
 while read -r key value; do case "$key" in oom) oom=$value;; oom_kill) kills=$value;; esac; done < /sys/fs/cgroup/memory.events
 ui_pid=0; ui_rss=0; xr_pid=0; xr_rss=0; probe_pid=0; probe_rss=0
 for process in /proc/[0-9]*; do
  [ -r "$process/comm" ] || continue
  read -r name < "$process/comm" || continue
  case "$name" in x-ui|xray|agent)
   rss=0
   while read -r key value unit; do [ "$key" != VmRSS: ] || rss=$value; done < "$process/status" 2>/dev/null || continue
   case "$name" in x-ui) ui_pid=${process##*/}; ui_rss=$rss;; xray) xr_pid=${process##*/}; xr_rss=$rss;; agent) probe_pid=${process##*/}; probe_rss=$rss;; esac
  ;; esac
 done
 printf '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n' "$uptime" "$total" "$swap" "$anon" "$sock" "$oom" "$kills" "$ui_pid" "$ui_rss" "$xr_pid" "$xr_rss" "$probe_pid" "$probe_rss"
 sleep .5
done
