"""Disposable PostgreSQL + exact production binary, synthetic data only."""
import hashlib,json,os,pathlib,pwd,secrets,shutil,socket,subprocess,time,uuid
R=pathlib.Path('/var/lib/nat-accounting-20261108')
assert not R.exists(), 'Refusing to reuse an existing fixture'
assert int(subprocess.check_output(['systemctl','show','x-ui','-p','MainPID','--value']))==437
R.mkdir(mode=0o755)
for d in ['install/bin','db','log','pg','sock']:
    (R/d).mkdir(parents=True,exist_ok=True)
pg=pwd.getpwnam('postgres')
for d in ['pg','sock']:
    os.chown(R/d,pg.pw_uid,pg.pw_gid); (R/d).chmod(0o700)
for src,dst in [('/usr/local/x-ui/x-ui','install/x-ui'),('/usr/local/x-ui/bin/xray-linux-amd64','install/bin/xray-linux-amd64')]:
    shutil.copy2(src,R/dst)
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert sha(R/'install/x-ui')=='c500bf1b46d4f16b95c87b4906915b2413f37b25b9b24af8314979da66d4b148'
def run(args,**kw): return subprocess.run(args,check=True,timeout=60,**kw)
with (R/'initdb.log').open('w') as f:
    run(['runuser','-u','postgres','--','/usr/lib/postgresql/15/bin/initdb','-D',str(R/'pg'),'--auth-local=trust','--auth-host=reject','--no-locale','--encoding=UTF8'],stdout=f,stderr=f)
common=f'''NoNewPrivileges=yes
ProtectSystem=strict
ProtectHome=yes
ReadWritePaths={R}
InaccessiblePaths=/etc/x-ui /usr/local/x-ui /var/lib/postgresql
CPUQuota=40%
Nice=15
RuntimeMaxSec=5400
Restart=no
'''
pgunit=f'''[Unit]
Description=Disposable NAT accounting PostgreSQL
[Service]
User=postgres
ExecStart=/usr/lib/postgresql/15/bin/postgres -D {R}/pg -k {R}/sock -p 55432 -c listen_addresses= -c shared_buffers=16MB -c max_connections=20 -c work_mem=1MB -c maintenance_work_mem=8MB
MemoryMax=160M
{common}'''
pathlib.Path('/run/systemd/system/nat-accounting-pg.service').write_text(pgunit)
run(['systemctl','daemon-reload']);run(['systemctl','start','nat-accounting-pg'])
pgargs=['psql','--no-psqlrc','-h',str(R/'sock'),'-p','55432','-U','postgres','-d','postgres','-qAt','-v','ON_ERROR_STOP=1']
for _ in range(20):
    if subprocess.run(pgargs+['-c','SELECT 1'],capture_output=True).returncode==0: break
    time.sleep(.5)
run(pgargs+['-c','CREATE DATABASE nat_fixture'])
pgargs[pgargs.index('-d')+1]='nat_fixture'
ports=[]
for _ in range(2):
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0)); ports.append(sock.getsockname()[1])
s={'port':ports[0],'api_port':ports[1],'base':'/test-'+secrets.token_hex(12)+'/',
   'token':secrets.token_hex(32),'guid':str(uuid.uuid4()),'username':'fixture-'+secrets.token_hex(6),'password':secrets.token_hex(24),
   'masterSha':sha(R/'install/x-ui'),'xraySha':sha(R/'install/bin/xray-linux-amd64')}
(R/'state.json').write_text(json.dumps(s)); (R/'state.json').chmod(0o600)
env={'PATH':'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','HOME':str(R),
    'XUI_DB_TYPE':'postgres','XUI_DB_DSN':f'host={R}/sock port=55432 user=postgres dbname=nat_fixture sslmode=disable',
    'XUI_DB_FOLDER':str(R/'db'),'XUI_BIN_FOLDER':str(R/'install/bin'),'XUI_LOG_FOLDER':str(R/'log'),
    'XUI_NODE_TOKEN_KEY_FILE':str(R/'db/key.json'),'NODE_TOKEN_ENCRYPTION':'off','XUI_ENABLE_FAIL2BAN':'false',
    'XUI_DB_MAX_OPEN_CONNS':'8','XUI_DB_MAX_IDLE_CONNS':'4','GOMEMLIMIT':'128MiB','GOGC':'75','GOMAXPROCS':'2'}
(R/'master.env').write_text(''.join(k+'="'+v+'"\n' for k,v in env.items()));(R/'master.env').chmod(0o600)
with (R/'initialize.log').open('w') as log:
    run([str(R/'install/x-ui'),'setting','-port',str(s['port']),'-listenIP','127.0.0.1','-webBasePath',s['base'],'-username',s['username'],'-password',s['password']],cwd=R/'install',env=env,stdout=log,stderr=log)
template={'log':{'access':'none','error':'none','loglevel':'warning'},
 'api':{'tag':'api','services':['HandlerService','LoggerService','StatsService','RoutingService']},
 'inbounds':[{'listen':'127.0.0.1','port':s['api_port'],'protocol':'tunnel','settings':{'rewriteAddress':'127.0.0.1'},'tag':'api'}],
 'outbounds':[{'protocol':'blackhole','tag':'blocked'}],'routing':{'rules':[{'type':'field','inboundTag':['api'],'outboundTag':'api'}]},
 'policy':{'levels':{'0':{'statsUserUplink':True,'statsUserDownlink':True}},'system':{'statsInboundUplink':True,'statsInboundDownlink':True}},'stats':{}}
values={'subEnable':'false','subJsonEnable':'false','subClashEnable':'false','tgBotEnable':'false','webDomain':'','twoFactorEnable':'false','webCertFile':'','webKeyFile':'','panelGuid':s['guid'],'xrayTemplateConfig':json.dumps(template)}
def quote(v):return "'"+str(v).replace("'","''")+"'"
sql='BEGIN;\n'
for k,v in values.items():
    sql+='DELETE FROM settings WHERE key='+quote(k)+'; INSERT INTO settings(key,value) VALUES('+quote(k)+','+quote(v)+');\n'
sql+='INSERT INTO api_tokens(name,token,enabled,created_at,scope,expires_at) VALUES(\'accounting-fixture\','+quote(hashlib.sha256(s['token'].encode()).hexdigest())+',true,'+str(int(time.time()))+",'admin',0); COMMIT;"
run(pgargs,input=sql,text=True,capture_output=True)
unit=f'''[Unit]
Description=Disposable exact-version NAT accounting master
Requires=nat-accounting-pg.service
After=nat-accounting-pg.service
[Service]
WorkingDirectory={R}/install
ExecStart={R}/install/x-ui
EnvironmentFile={R}/master.env
MemoryMax=256M
StandardOutput=append:{R}/master.log
StandardError=append:{R}/master.log
{common}'''
pathlib.Path('/run/systemd/system/nat-accounting-master.service').write_text(unit)
run(['systemctl','daemon-reload']);run(['systemctl','start','nat-accounting-master'])
print(json.dumps({'fixture':str(R),'masterSha':s['masterSha'],'xraySha':s['xraySha'],'database':'isolated PostgreSQL 15','productionDataCopied':False,'webBind':'127.0.0.1','port':s['port']}))
