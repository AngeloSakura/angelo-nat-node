import json,pathlib,ssl,urllib.request
R=pathlib.Path('/var/lib/nat-accounting-20261108')
nodes=json.loads((R/'benchmark-private.json').read_text())
results=[]
for node in nodes:
    ctx=ssl.create_default_context(cadata=node['certificate']);ctx.check_hostname=False
    def api(route):
        req=urllib.request.Request('https://'+node['host']+':50001/panel/api/'+route,headers={'Authorization':'Bearer '+node['token']})
        with urllib.request.urlopen(req,context=ctx,timeout=15) as response: r=json.load(response)
        assert r['success'];return r['obj']
    status=api('server/health');inbounds=api('inbounds/list')
    assert status['xray']['state']=='running' and not inbounds
    results.append({'node':node['name'],'xrayRunning':True,'inbounds':0})
(R/'postcheck-evidence.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results))
